﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public static GameManager instance = null;

    public Text timer;
    public Text mole;
    public float time = 300;
    public int score = 0;
    public int highScore;

    void Awake()
    {
        instance = this;
    }

    void Start()
    {
        mole.GetComponent<Text>().text = "Score: " + score;

        //update timer on UI
        timer.GetComponent<Text>().text = "Time: " + time;


        //Identify when mole is hit, adds time and score based on which mole variant (missing a triple mole does not give a x3 penalty)
        // UpdateScore(int addScore);
    }

    void Update()
    {
        time = time - Time.deltaTime;
        timer.GetComponent<Text>().text = "Time: " + time;


        //set highscore
        /*
        if (PlayerPrefs.HasKey("hiScore"))
        {
            if (score > PlayerPrefs.GetInt("hiScore"))
            {
                highScore = score;
                PlayerPrefs.SetInt("hiScore", highScore);
                PlayerPrefs.Save();
            }
        }
        else
        {
            if (score > highScore)
            {
                highScore = score;
                PlayerPrefs.SetInt("hiScore", highScore);
                PlayerPrefs.Save();
            }
        }
        */

        if (time <= 0 && score >= 10)
        {
            SceneManager.LoadScene("WinScene");
        }
        else if (time <= 0 && score < 10)
        {
            SceneManager.LoadScene("LoseScene");
        }

    }

    public void UpdateScore(int addScore = 0)
    {
        score += addScore;
        mole.GetComponent<Text>().text = "Score: " + score;
    }

    public void Restart()
    {
        SceneManager.LoadScene("SampleScene");
    }
}
