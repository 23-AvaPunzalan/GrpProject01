﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandoScript : MonoBehaviour
{
    public float SpawnChance;
    public float TripleChance;
    public float Timer = 5f;
    public GameObject Mole;
    public GameObject TripleMole;
    void Update()
    {
        SpawnChance = Random.Range(0, 10);
        TripleChance = Random.Range(0, 10);
        new WaitForSeconds(Timer);
        if (SpawnChance >= 3 || TripleChance >= 2)
        {
            new WaitForSeconds(Timer);
            transform.position = new Vector3(0, 5, 0);
            new WaitForSeconds(Timer);
            transform.position = new Vector3(0, 0, 0);
        }
        if (SpawnChance >= 3 || TripleChance <= 0)
        {
            new WaitForSeconds(Timer);
            MoleSwap();
            transform.position = new Vector3(0, 5, 0);
            new WaitForSeconds(Timer);
            transform.position = new Vector3(0, 0, 0);
            MoleSwap();
        }
    }
    void MoleSwap()
    {
        
        if (gameObject.tag=="Mole")
        {
            Destroy(gameObject);
            Instantiate(TripleMole);
        }
        if (gameObject.tag=="3Moles")
        {
            Destroy(gameObject);
            Instantiate(Mole);
        }
    }
}
