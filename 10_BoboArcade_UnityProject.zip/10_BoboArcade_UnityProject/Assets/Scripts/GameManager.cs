﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public static GameManager instance = null;

    public Text timer;
    public Text mole;
    public Text highscoreText;
    public float time = 300;
    public static int score = 0;
    public static int highScore = 0;

    void Awake()
    {
        instance = this;
    }

    void Start()
    {
        mole.GetComponent<Text>().text = "Score: " + score;

        highScore = PlayerPrefs.GetInt("highScore", highScore);
        highscoreText.GetComponent<Text>().text = "Highscore: " + highScore.ToString();

        //update timer on UI
        timer.GetComponent<Text>().text = "Time: " + time;


        //Identify when mole is hit, adds time and score based on which mole variant (missing a triple mole does not give a x3 penalty)
        // UpdateScore(int addScore);
    }

  

    void Update()
    {
        time = time - Time.deltaTime;
        timer.GetComponent<Text>().text = "Time: " + time;


        //set highscore
        if (score > highScore)
        {
            PlayerPrefs.SetInt("highScore", score);
            highscoreText.GetComponent<Text>().text = "Highscore: " + highScore.ToString();
            PlayerPrefs.Save();
        }
        /*
        if (PlayerPrefs.HasKey("highScore"))
        {
            if (score > PlayerPrefs.GetInt("highScore"))
            {
                UpdateHighScore();
            }
        }
        else
        {
            if (score > highScore)
            {
                UpdateHighScore();
            }
        }
        */

        if (time <= 0 && score >= 10)
        {
            SceneManager.LoadScene("WinScene");
        }
        else if (time <= 0 && score < 10)
        {
            SceneManager.LoadScene("LoseScene");
        }

    }

    public void UpdateScore(int addScore = 0)
    {
        score += addScore;
        mole.GetComponent<Text>().text = "Score: " + score;
    }

    public void Restart()
    {
        SceneManager.LoadScene("SampleScene");

    }
    public void Instruction()
    {
        SceneManager.LoadScene("InstructionScene");

    }

    public void TimerDeduct(float minusTime)
    {

        time -= minusTime;

    }
    /*
    private void UpdateHighScore()
    {
        //highScore = score;
        PlayerPrefs.SetInt("highScore", score);
        highscoreText.GetComponent<Text>().text = "Highscore: " + highScore.ToString();
        PlayerPrefs.Save();
        
    }
    */
}
