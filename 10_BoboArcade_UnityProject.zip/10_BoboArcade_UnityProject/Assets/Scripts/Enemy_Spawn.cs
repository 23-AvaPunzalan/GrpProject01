﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Spawn : MonoBehaviour
{

    [Header("Put Spawner")]
    private Transform[] spawnChild;
    public GameObject[] spawns;    
    [Header("Enemy")]
    public GameObject[] obstacle;
    [Header("spawn hight")]
    public float hight;    
    //private
    private int maxSpawn=0;
    private int maxObstacle;
    private int selectedSpawn;
    private int rand;
    private int randomInt;


    // Start is called before the first frame update
    void Start()
    {
        maxSpawn = spawns[randomInt].transform.childCount;
        maxObstacle = obstacle.Length;

        setup();
        InvokeRepeating("spawn",1, 1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //seting up the spawner
    void setup()
    {

        randomInt = Random.Range(0, spawns.Length);

        spawnChild = new Transform[spawns[randomInt].transform.childCount];

        for (int i = 0; i < spawns[randomInt].transform.childCount; i++)
        {
            spawnChild[i] = spawns[randomInt].transform.GetChild(i).transform;
        }

    }
    //spawn
    void spawn()
    {
        pipechecker();
        Instantiate(obstacle[rand], pipeSpawnPosition(), Quaternion.identity);
    }
    //Marking where to spawn 
    Vector3 pipeSpawnPosition()
    {

        return new Vector3(spawnChild[rand].transform.position.x,spawnChild[rand].transform.position.y + hight,spawnChild[rand].transform.position.z);
    }

    //Using random to check where to spawn/check if it's clear to spawn
    void pipechecker()
    {
        int one, two, three, four, five, six, seven;
        bool allowSpawn;

        rand = Random.Range(0, maxSpawn);
        if (rand == 1)
        {
            one = 1; allowSpawn = one != 1;
        }
        if (rand == 2)
        {
            two = 1; allowSpawn = two != 1;
        }
        if (rand == 3)
        {
            three = 1; allowSpawn = three != 1;
        }
        if (rand == 4)
        {
            four = 1; allowSpawn = four != 1;
        }
        if (rand == 5)
        {
            five = 1; allowSpawn = five != 1;
        }
        if (rand == 6)
        {
            six = 1; allowSpawn = six != 1;
        }
        if (rand == 7)
        {
            seven = 1; allowSpawn = seven != 1;
        }
    }




}
